//
//  ViewController3.swift
//  GroceryApp
//
//  Created by Apple on 4/3/22.
//

import UIKit

class ViewController3: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tb1: UITableView!
    var chathistory = [String]()
    var receiver1 = " "
    var sender1: String = " "
    @IBOutlet weak var textt: UITextField!
   //chatbot button
    @IBAction func btnchat(_ sender: Any) {
        sender1 = String(textt.text!)
        chathistory.append(sender1)
        if sender1.contains("long"){
            receiver1 = "We will ship the product within 3 hours."
            chathistory.append(receiver1)
        }else if sender1.contains("checkout"){
            receiver1 = "Click the button below the cart page."
            chathistory.append(receiver1)
        }else if sender1.contains("founder"){
            receiver1 = "The name of founder is John and Chin Choong"
            chathistory.append(receiver1)
        }else if sender1.contains("not fresh"){
            receiver1 = "Sorry! Please contact 012-3456789 for refund or exchange."
            chathistory.append(receiver1)
        }else{
            receiver1 = "Welcome to our grocery! May I help you?"
            chathistory.append(receiver1)
        }
        tb1.reloadData()
    }
    
    func numberOfSections(_ tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chathistory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "chatcell") as! TableViewCellchat
        cell.chatlabel.text = chathistory[indexPath.row]
        if ((indexPath.row)%2==1)
        {
            cell.rightlabel.text = "Chatbot"
        }else{
            cell.rightlabel.text = "Me"
        }
        return cell
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tb1.delegate = self
        tb1.dataSource = self// Do any additional setup after loading the view.
        
    }
    
    
override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    }

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


//
//  ViewController4.swift
//  GroceryApp
//
//  Created by Apple on 4/3/22.
//


import UIKit
import Firebase
import FirebaseStorage
import FirebaseFirestore

class ViewController4: UIViewController{
    
    
    
    
    @IBOutlet weak var stock2: UILabel!
    @IBOutlet weak var net_weight2: UILabel!
    @IBOutlet weak var dateImport2: UILabel!
    @IBOutlet weak var status2: UILabel!
    @IBOutlet weak var origin2: UILabel!
    @IBOutlet weak var pr2: UILabel!
    @IBOutlet weak var name2: UILabel!
    @IBOutlet weak var imge2: UIImageView!
    @IBOutlet weak var imge1: UIImageView!
    @IBOutlet weak var name1: UILabel!
    @IBOutlet weak var pr1: UILabel!
    @IBOutlet weak var origin: UILabel!
    @IBOutlet weak var status1: UILabel!
    @IBOutlet weak var dateImport1: UILabel!
    @IBOutlet weak var stock1: UILabel!
    @IBOutlet weak var net_weight1: UILabel!
    let vc = ViewController()
    var item = [String]()
    var filteredData:[String]!
    @IBOutlet weak var searchBar: UISearchBar!
    var all_price = [Int]()
    //detail of all
    var dateimport = [String]()
    var status = [String]()
    var net_weight = [String]()
    var origin1 = [String]()//diff name
    var stock = [Int]()
    var key: Int = 0
    
    @IBOutlet weak var sg1: UISegmentedControl!
    //Database Retrieve
    var databaseHandle:DatabaseHandle?
    private let ref = Database.database().reference()
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        filteredData = item
        // Do any additional setup after loading the view.
        databaseHandle = ref.child("vegetable").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
            
            if let actualPost = post{
                self.item.append(actualPost)
                print(self.item)
                self.tableView.reloadData()
            }
        
        })//end of databasehandle
        tableView.reloadData()
        let try1 = ref.child("vegetable")
        try1.observe(.childAdded) { (snapshot) in
            if let price = snapshot.value as? NSDictionary{
                let p = price["price"]! as? Int
                self.all_price.append(p!)
            }
        }
        let try2 = ref.child("vegetable")
        try2.observe(.childAdded) { (snapshot) in
            if let price = snapshot.value as? NSDictionary{
                let p = price["status"]! as? String
                self.status.append(p!)
            }
        }
        let try3 = ref.child("vegetable")
        try3.observe(.childAdded) { (snapshot) in
            if let price = snapshot.value as? NSDictionary{
                let p = price["date import"]! as? String
                self.dateimport.append(p!)
            }
        }
        let try4 = ref.child("vegetable")
        try4.observe(.childAdded) { (snapshot) in
            if let price = snapshot.value as? NSDictionary{
                let p = price["net_weight"]! as? String
                self.net_weight.append(p!)
            }
        }
        let try5 = ref.child("vegetable")
        try5.observe(.childAdded) { (snapshot) in
            if let price = snapshot.value as? NSDictionary{
                let p = price["origin"]! as? String
                self.origin1.append(p!)
            }
        }
        let try6 = ref.child("vegetable")
        try6.observe(.childAdded) { (snapshot) in
            if let price = snapshot.value as? NSDictionary{
                let p = price["stock"]! as? Int
                self.stock.append(p!)
            }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
}
    
    @IBAction func segmentControl(_ sender: Any) {
        print(item)
        print(origin1)
        switch sg1.selectedSegmentIndex{
            case 0:
                key = 0
                tableView.reloadData()
            case 1:
                key = 1
                tableView.reloadData()
            default:
                print("error")
    }
  
    }
                

    


}


extension ViewController4: UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate{
    func numberOfSections(_ tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell 4") as! TableViewCellTest
        cell.lebel1.text = filteredData[indexPath.row]
        return cell
    }
    //main function to display selected item
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if key == 0{
        name1.text = item[indexPath.row]
        pr1.text = String(all_price[indexPath.row])
        origin.text = origin1[indexPath.row]
        status1.text = status[indexPath.row]
        dateImport1.text = dateimport[indexPath.row]
        stock1.text = net_weight[indexPath.row]
        net_weight1.text = String(stock[indexPath.row])
        imge1.image = UIImage(named: item[indexPath.row])
            self.tableView.isHidden = true}
        else if key == 1{
            name2.text = item[indexPath.row]
            pr2.text = String(all_price[indexPath.row])
            origin2.text = origin1[indexPath.row]
            status2.text = status[indexPath.row]
            dateImport2.text = dateimport[indexPath.row]
            net_weight2.text = net_weight[indexPath.row]
            stock2.text = String(stock[indexPath.row])
            imge2.image = UIImage(named: item[indexPath.row])
                self.tableView.isHidden = true}
        }
    //Search function to search certain item
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredData = []
        
        if searchText == ""{
            filteredData = item
            self.tableView.isHidden = true
        }else{
            self.tableView.isHidden = false
        }
        for n in item{
            if n.lowercased().contains(searchText.lowercased()){
                filteredData.append(n)
                
            }
            
        }
        self.tableView.reloadData()
    }
}


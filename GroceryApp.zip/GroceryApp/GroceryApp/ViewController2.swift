//
//  ViewController.swift
//  GroceryApp
//
//  Created by Apple on 3/23/22.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseFirestore
import CoreLocation

let vc = ViewController()
class ViewController2: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var test111: UIButton!
    private var locationManager: CLLocationManager?
    var test_array = [String]()
    var ref:DatabaseReference?
    var postData = [String]()
    var totalpriceproduct = [Int]()
    var totalprice = 0
    var tStep = [Int]()
    var count = [Int](repeating: 1, count: 3)
    var past_count = [Int](repeating: 0, count: 3)
    @IBOutlet weak var lokasi: UILabel!
    @IBOutlet weak var T1: UITableView!
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var totaldisplay: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        T1.delegate = self
        T1.dataSource = self
        payment.delegate = self
        payment.dataSource = self
        
       
        locationManager = CLLocationManager()
        locationManager?.requestAlwaysAuthorization()
        locationManager?.startUpdatingLocation()
        locationManager?.delegate = self
        locationManager?.allowsBackgroundLocationUpdates = true
        
    } //automatic retrieve location of user
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last{
            lokasi.text = "Latitude : \(location.coordinate.latitude)  Longitude : \(location.coordinate.longitude)"
    }
    }
    
  
    
    
    @IBAction func checkOut(_ sender: Any) {
        var alert = UIAlertController(title:"Are you sure you want to check out?", message: "Please ensure that the item in the cart is the item you want to purchase", preferredStyle: .alert)
        let defaultAction = UIAlertAction(title: "Yes", style: .default, handler: nil)
        let cancelAction = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        alert.addAction(defaultAction)
        alert.addAction(cancelAction)
        
        present(alert,animated: true,completion: nil)
    }

    @IBOutlet weak var payment: UIPickerView!
    let pickerData = ["Tng E-wallet","Credit Card","Online Banking","Cash"]
}

//configuration for lokasi
extension ViewController2:UIPickerViewDelegate, UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView:UIPickerView, titleForRow row:Int, forComponent component: Int) -> String?{
        return pickerData[row]
    }
    func pickerView(_ pickerView:UIPickerView, didSelectRow row:Int, inComponent component: Int){
        lokasi.text = pickerData[row]
    }
}
//table view for cart page
extension ViewController2: UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(_ tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vc.cart_item.count
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell 2") as! customCell1
        cell.lb1.text = vc.cart_item[indexPath.row]
        //OOP
        let result = calculation(vc.cart_price[indexPath.row],count[indexPath.row],totalprice,past_count[indexPath.row])
        totalprice = result.alltotal()
        past_count[indexPath.row] = count[indexPath.row]
        //end of OOP
        //label
        cell.lb2.text = String((vc.cart_price[indexPath.row]))
        print(String((vc.cart_item[indexPath.row])))
        cell.lb3.text = String(result.producttotal())
        cell.count1.text = String(count[indexPath.row])
        cell.img1.image = UIImage(named: vc.cart_item[indexPath.row])
        
        //stepper function
        cell.plusbtn.tag = indexPath.row
        cell.minusbtn.tag = indexPath.row
        cell.plusbtn.addTarget(self, action: #selector(plusc), for: .touchUpInside)
        cell.minusbtn.addTarget(self, action: #selector(minusc), for: .touchUpInside)
        totaldisplay.text = "RM \(String(totalprice))"
        return cell
    }
    @objc func plusc(sender:UIButton)
    {
        let ipman1 = IndexPath(row:sender.tag,section: 0)
        count[ipman1.row] += 1
        self.tableview.reloadData()
        }
    
    @objc func minusc(sender:UIButton)
    {
        let ipman2 = IndexPath(row:sender.tag,section: 0)
        count[ipman2.row] -= 1
        self.tableview.reloadData()
        }

    }
    
    


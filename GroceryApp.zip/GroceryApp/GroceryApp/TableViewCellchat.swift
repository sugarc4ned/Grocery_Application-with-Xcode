//
//  TableViewCellchat.swift
//  GroceryApp
//
//  Created by Apple on 4/3/22.
//

import UIKit

class TableViewCellchat: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var chatlabel: UILabel!
    
    @IBOutlet weak var rightlabel: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

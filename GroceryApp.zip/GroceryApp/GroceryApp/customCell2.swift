//
//  customCell2.swift
//  GroceryApp
//
//  Created by Apple on 3/31/22.
//

import UIKit

class customCell2: UITableViewCell {

    
    @IBOutlet weak var menuview1: UIView!
    
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var labe1: UILabel!
    @IBOutlet weak var labe2: UILabel!
    @IBOutlet weak var bt2: UIButton!
    
    @IBOutlet weak var favbtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  customCell1.swift
//  GroceryApp
//
//  Created by Apple on 3/29/22.
//

import UIKit

class customCell1: UITableViewCell {


    @IBOutlet weak var shoppinglist: UIView!

    @IBOutlet weak var lb1: UILabel!
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var count1: UILabel!
    @IBOutlet weak var lb3: UILabel!
    @IBOutlet weak var lb2: UILabel!
    
    @IBOutlet weak var plusbtn: UIButton!
    
    @IBOutlet weak var minusbtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func stAc(_ sender: UIStepper) {
        self.lb3.text = Int(sender.value).description
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

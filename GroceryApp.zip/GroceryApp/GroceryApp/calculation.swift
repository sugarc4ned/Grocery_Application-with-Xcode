//
//  calculation.swift
//  GroceryApp
//
//  Created by Apple on 4/3/22.
//

import Foundation

class calculation{
    private let costOfItem :Int?
    private let amtitem:Int?
    private let total1:Int?
    private let pastc:Int?
    
    init(_ costOfItem:Int?,_ amtitem:Int?,_ totaltotal:Int?,_ pastcount:Int?) {
        self.costOfItem = costOfItem
        self.amtitem = amtitem
        self.total1 = totaltotal
        self.pastc = pastcount
    }
    
    func producttotal()->Int{
        let a:Int = costOfItem! * amtitem!
        return (a)
    }
    
    func alltotal()->Int{
        if (amtitem! > pastc!){
            print("plus")
            return (total1! + costOfItem!)
        }else if(amtitem! == pastc!){
            print("equal")
            return(total1!)
        }
        else{
            print("minus")
            return (total1! - costOfItem!)
        }
        
    }
    
    
}



//
//  ViewController.swift
//  GroceryApp
//
//  Created by Apple on 3/23/22.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseFirestore

class ViewController: UIViewController {
    

    
    
    @IBOutlet weak var lokasi: UILabel!
    @IBOutlet weak var T1: UITableView!
    @IBOutlet weak var tableview: UITableView!
    
    var arrayOfQuestions:Array<String> = ["First"]

    //Database Retrieve
    var databaseHandle:DatabaseHandle?
    private let ref = Database.database().reference()
    
    //temp data for table view
    var postData = [String]()
    var postPrice = [Int?]()
    //data (categories)&(price of categories)
    var vegetable = [String]()
    var vg_price = [Int?]()
    var fruit = [String]()
    var fr_price = [Int?]()
    var frozen_food = [String]()
    var fz_price = [Int?]()
    var all = [String](arrayLiteral: "apple")
    var all_price = [Int?](arrayLiteral: 1)
    var fav_item = [String]()
    
    //detail of all
    var dateimport = [String]()
    var status = [String]()
    var net_weight = [String]()
    var origin = [String]()
    var id = [Int]()
    var price = [Int]()
    var stock = [Int]()
    var add : Int = 0
    
    //cart function
    var cart_item =  ["apple","potato","pak choi"]
    var cart_price = [2,5,4]
    var isActive = [Int](repeating: 0, count: 50)

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableview.delegate = self
        tableview.dataSource = self
        
        //begin of data R1
        databaseHandle = ref.child("vegetable").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
            
            if let actualPost = post{
                self.vegetable.append(actualPost)
                self.all.append(actualPost)
                self.postData = self.vegetable //change the table categories
                
                self.tableview.reloadData()
                print(self.vegetable)
                //self.tableview.reloadData()
            }
        })//end of databasehandle
        let try1 = ref.child("vegetable")
            //try1.queryOrderedByKey()
        try1.observe(.childAdded) { (snapshot) in
            if let price = snapshot.value as? NSDictionary{
                //print(price)
                let p = price["price"]! as? Int
                //print(p!)
                self.vg_price.append(p)
                self.postPrice = self.vg_price
                self.all_price.append(p)
                self.tableview.reloadData()
                //self.all.append(price["origin"])
                //print(self.all_price)
            }
        }//end of R1
        //begin of data R2
        databaseHandle = ref.child("Fruit").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
                if let actualPost = post{
                    self.fruit.append(actualPost)
                    self.all.append(actualPost)
                    print(self.fruit)
                    //self.postData = self.fruit
                    //self.tableview.reloadData()
                }
            })//end of databasehandle
            let try2 = ref.child("Fruit")
            try2.observe(.childAdded) { (snapshot) in
                if let pr = snapshot.value as? NSDictionary{
                    let prF = pr["price"]! as? Int
                    //print (prF!)
                    self.fr_price.append(prF)
                    self.all_price.append(prF)
                }
    
            }//end of R2
        //begin of data R3
        databaseHandle = ref.child("Frozen_food").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
                if let actualPost = post{
                    self.frozen_food.append(actualPost)
                    self.all.append(actualPost)
                    //self.postData = self.fruit
                    //self.tableview.reloadData()
                }
            })//end of databasehandle
            let try3 = ref.child("Frozen_food")
            try3.observe(.childAdded) { (snapshot) in
                if let pr = snapshot.value as? NSDictionary{
                    let prF = pr["price"]! as? Int
                    //print (prF!)
                    self.fz_price.append(prF)
                    self.all_price.append(prF)
                }
    
            }//end of R3
        //begin of data R4(all)
        databaseHandle = ref.child("Bakery").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
                if let actualPost = post{
                    self.all.append(actualPost)
                    //self.postData = self.fruit
                    //self.tableview.reloadData()
                }
            })//end of databasehandle
        databaseHandle = ref.child("Beverage").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
                if let actualPost = post{
                    self.all.append(actualPost)
                    //self.postData = self.fruit
                    //self.tableview.reloadData()
                }
            })//end of databasehandle
        databaseHandle = ref.child("Meat").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
                if let actualPost = post{
                    self.all.append(actualPost)
                    //self.postData = self.fruit
                    //self.tableview.reloadData()
                }
            })//end of databasehandle
        databaseHandle = ref.child("Snack").observe(.childAdded, with: { (snapshot) in
            let post = snapshot.value as? String
                if let actualPost = post{
                    self.all.append(actualPost)
                    //self.postData = self.fruit
                    //self.tableview.reloadData()
                }
            })//end of databasehandle
            let try4 = ref.child("Bakery")
            try4.observe(.childAdded) { (snapshot) in
                if let pr = snapshot.value as? NSDictionary{
                    let prF = pr["price"]! as? Int
                    //print (prF!)
                    self.all_price.append(prF)                }
            }
            let try5 = ref.child("Beverage")
            try5.observe(.childAdded) { (snapshot) in
                if let pr = snapshot.value as? NSDictionary{
                    let prF = pr["price"]! as? Int
                    //print (prF!)
                    self.all_price.append(prF)
                }
            }
            let try6 = ref.child("Meat")
            try6.observe(.childAdded) { (snapshot) in
                if let pr = snapshot.value as? NSDictionary{
                    let prF = pr["price"]! as? Int
                    //print (prF!)
                    self.all_price.append(prF)
                }}
            let try7 = ref.child("Snack")
            try7.observe(.childAdded) { (snapshot) in
                if let pr = snapshot.value as? NSDictionary{
                    let prF = pr["price"]! as? Int
                    //print (prF!)
                    self.all_price.append(prF)
                }
    
            }//end of R4
        }//end of override func

        
    override func didReceiveMemoryWarning(){
            super.didReceiveMemoryWarning()
        }
        

    
    @IBOutlet weak var segment1: UISegmentedControl!
    
    //segment to control the 4 categories
    @IBAction func segmentControl(_ sender: Any) {
        switch segment1.selectedSegmentIndex{
            case 0:
                postData.removeAll()
                postData.append(contentsOf:vegetable)
                postPrice.removeAll()
                postPrice.append(contentsOf: vg_price)
                tableview.reloadData()
            case 1:
                postData.removeAll()
                postData.append(contentsOf: fruit)
                postPrice.removeAll()
                postPrice.append(contentsOf: fr_price)
                tableview.reloadData()
            case 2:
                postData.removeAll()
                postData.append(contentsOf: frozen_food)
                postPrice.removeAll()
                postPrice.append(contentsOf: fz_price)
                tableview.reloadData()
            case 3:
                postData.removeAll()
                postData.append(contentsOf: all)
                postPrice.removeAll()
                postPrice.append(contentsOf: all_price)
                tableview.reloadData()
            default:
                print ("error")
    }
            
        
    }
    
}

//table view configuration with fav button, add to cart
extension ViewController: UITableViewDelegate, UITableViewDataSource{

    func numberOfSections(_ tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 95
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return vcData.names.count
        return postData.count
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell 1") as! customCell2
        cell.labe1.text = postData[indexPath.row]
        cell.labe2.text = String(postPrice[indexPath.row]!)
        cell.img2.image = UIImage(named: postData[indexPath.row])
        cell.bt2.tag = indexPath.row
        cell.bt2.addTarget(self, action: #selector(addtocart), for: .touchUpInside)
        cell.favbtn.tag = indexPath.row
        cell.favbtn.addTarget(self, action: #selector(favplus), for: .touchUpInside)
        
        if isActive[indexPath.row] == 1{
            cell.favbtn.setImage(UIImage(named: "love"), for: .normal)
        }else{
            cell.favbtn.setImage(UIImage(named: "nolove"), for: .normal)
        }
        return cell
        
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("done")
    }
    @objc func favplus(sender:UIButton)
    {
        let ipman1 = IndexPath(row:sender.tag,section: 0)
        fav_item.append(postData[ipman1.row])
        self.tableview.reloadData()
        print(fav_item)
        if isActive[ipman1.row] == 1{
            isActive[ipman1.row] = 0
        }else{
            isActive[ipman1.row] = 1
        }

    }
    @objc func addtocart(sender:UIButton)
    {
        let ipman = IndexPath(row:sender.tag,section: 0)
        cart_item.append(postData[ipman.row])
        cart_price.append(Int(postPrice[ipman.row]!))
        self.tableview.reloadData()
        print(cart_item,cart_price)
    }
    }


//
//  ViewController5.swift
//  GroceryApp
//
//  Created by Apple on 4/4/22.
//

import UIKit

class ViewController5: UIViewController {

    
    @IBOutlet weak var user: UITextField!
    @IBOutlet weak var pass: UITextField!
    
    //username and password database
    var userdata = ["john","choong","ali"]
    var passdata = ["123","123","123"]
    //verify boolean key
    var key = 0
    var key1 = 0
    var key2 = 0
    
    @IBAction func loginbtn(_ sender: Any) {
        //get user input
        let a = String(user.text!)
        let b = String(pass.text!)
        //if username correct
        for n in userdata{
            if (n == a.lowercased()){
                key1 = 1
            }
        }//if password correct
        for n in passdata{
            if (n == b){
                key2 = 1
            }
        }//if both correct, navigate to main menu
        if (key1 == 1)&&(key2 == 1){
            self.performSegue(withIdentifier: "gogogo", sender: self)
        }
        else{
            print("Error")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
